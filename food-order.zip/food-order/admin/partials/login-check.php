<?php
    // 
    // check wheather user is logged in or not
	if(!isset($_SESSION['user']))
	{
		// user is not logged in
		// redirect to login page
		$_SESSION['no-login-message']= " <div class='error' text-centre > Please LOgin </div> ";
		header('location:'.SITEURL.'admin/login.php');
	}

?>