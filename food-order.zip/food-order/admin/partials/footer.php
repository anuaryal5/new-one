<!-- footer starts -->
<div class="footer">
            <div class="wrapper">
                <p class="text-centre">2021 All rights reserved, </p>
            </div>
        </div>
         <!-- footer ends -->

    </body>
</html>