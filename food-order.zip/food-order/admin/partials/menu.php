<?php
 include("../config/constants.php");
 include("login-check.php");

?>



<html>
    <head>
        <title> Food order website homepage </title>
        <link rel="stylesheet" href="../css/admin.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
    </head>

    <body>

        <!-- menu section starts -->
        <div class="menu text-centre">
            <div class="wrapper">
                <ul> 
                    <li> <a href="index.php"> Home </a> </li>
                    <li> <a href="manage-admin.php"> Admin  </a> </li>
                    <li> <a href="manage-category.php"> category </a> </li>
                    <li> <a href="manage-food.php"> food</a> </li>
                    <li> <a href="manage-order.php"> order </a> </li>
                    <li> <a href="logout.php"> Log out </a> </li>
                </ul>
            </div>
        </div>
         <!-- menu section ends -->