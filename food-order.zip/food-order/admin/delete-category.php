<?php 
	include('../config/constants.php');
	// check wheather the id and image_name value is set or not
	if (isset($_GET['id']) AND isset($_GET['image_name']))
	{
		// get value and delete
		$id = $_GET['id'];
		$image_name = $_GET['image_name'];

		// remove image file if available and only delete data from databse 
		if ($image_name != "") 
		{
			$path = "../images/category/".$image_name;
			// remove image
			$remove = unlink($path);

			// if fail to remove image add error message
			if($remove==FALSE)
			{
				// save session message
				$_SESSION['remove'] = "<div class='error'> Failed to remove image </div>";
				// redirect to manage category
				header('location:'.SITEURL.'admin/manage-category.php');
				// stop process
				die();
			}

		}

		$sql = "DELETE FROM tbl_category WHERE id=$id";

		$res = mysqli_query($conn,$sql);

		// check data is deleted or not

		if($res==TRUE)
		{
			// set sucess
			$_SESSION['delete'] = "<div class='success'> successfully dleted </div>";
			header('location:'.SITEURL.'admin/manage-category.php');
		}
		else
		{
			// set failed
			$_SESSION['delete'] = "<div class='error'> Failed to dleted </div>";
			header('location:'.SITEURL.'admin/manage-category.php');
		}

		// redirect to manage category with message
	}
	else
	{
		// redirect to manage category
		header('location:'.SITEURL.'admin/manage-category.php');
	}

?>