<?php include('../config/constants.php') ?>


<!DOCTYPE html>
<html>
<head>
  <title> Login Form </title>

    <link rel="stylesheet" type="text/css" href="../css/admin.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
</head>
<body>
  
    <div class="wrapper2">
      <div class="login">
      <h1 class="text-centre" style="color: red; padding-top: 20px; font-weight: bold;"> Login</h1>  

      <?php
        if(isset($_SESSION['login']))
        {
          echo $_SESSION['login'];
          unset($_SESSION['login']);
        }
        if(isset($_SESSION['no-login-message']))
        {
          echo $_SESSION['no-login-message'];
          unset($_SESSION['no-login-message']);
        }

      ?>
      <form action="" method="POST" class="text-centre">
        <div class="box">
        <div class="name-box">
          <input type="text" name="user_name" class="username" placeholder=" USERNAME">
          
        </div>
        <div class="pass-box">
          <input type="password" name="password" class="password" placeholder="PASSWORD">
          
        </div>
        
      </div>
       
        <input type="submit" name="submit" value="Login" class="button" >
     
        
      </form>
      </div>
      
    </div>
  

</body>
</html>


<?php 

  // check submit click or not
  if (isset($_POST['submit']))
  {
    // process for login
    // get data from login form

    $user_name = $_POST['user_name'];
    $password = md5($_POST['password']);

    // sql to check where username and password exist or not

    $sql = "SELECT *FROM tbl_admin WHERE user_name='$user_name' and password='$password'";

    // execute the query
    $res = mysqli_query($conn,$sql);

    // check count rows to check wheather the user exist or not
    $count = mysqli_num_rows($res);

      if($count==1)
      {
        // user exist and login success
        $_SESSION['login'] = "<div class='success text-centre'> <br> <bold>Login successful </bold></div>";
        $_SESSION['user'] = "$user_name"; //check wheather user is logged in or not
        header('location:'.SITEURL.'admin/index.php');

      }
      else
      {
        // user not available and login failed
        $_SESSION['login'] = "<div class='error text-centre'> <br>login fail</div>";
        header('location:'.SITEURL.'admin/login.php');
      }

  }


?>