<?php include('partials/menu.php'); ?>
		<div class="main-content">
			<div class="wrapper">
				<h1>Update Admin</h1>

				<br>
				<br>
				<?php
					// get id of selected admin

						$id=$_GET['id'];

					// create sql query to get id
						$sql="SELECT *FROM tbl_admin WHERE id=$id";
					// execute query
						$res=mysqli_query($conn,$sql);

					// check query execute or not
						if($res==TRUE)
						{
							// data available or not
							$count = mysqli_num_rows($res);

							// check we have data or not
							if($count==1)
							{
								// get detail
								// echo "admin available";
								$row =mysqli_fetch_assoc($res);

								$full_name = $row['full_name'];

								$user_name = $row['user_name'];
							}
							else
							{
								// redirect to manage-admin.php
								header('location:'.SITEURL.'admiin/manage-admin.php');
							}
						}
				?>

				<form action="" method="POST">

					<table class="tbl-100">
					<tr>
						<td>Full Name</td>
						<td><input type="text" name="full_name" value="<?php echo $full_name; ?>"></td>

					</tr>
					<tr>
						<td>User Name</td>
						<td> <input type="text" name="user_name" value="<?php echo $user_name; ?>"></td>
					</tr>

					<!-- <tr>
						<td>Password</td>
						<td> <input type="text" name="password" value=""></td>
					</tr>
 -->
					<tr>
						<td colspan="2">
							<input type="hidden" name="id" value="<?php echo $id; ?>">
							<input type="submit" name="submit" value="Update Admin" class="btn-secondary">
					</tr>

						


					</table>
					

				</form>
				

			</div>
			</div>

<?php 
		// check whether submit is click or not
		if(isset($_POST['submit']))
		{
			// echo "Button clicked";
			
			// Get all the values from form to update

			$id = $_POST['id'];
			$full_name = $_POST['full_name'];
			$user_name = $_POST['user_name'];


			// sal query to upfate admin

			$sql = " UPDATE tbl_admin SET full_name = '$full_name' , user_name = '$user_name' WHERE id = '$id' ";

			// executing query
			$res = mysqli_query($conn ,$sql) or die(mysqli_error($conn)) ;

			// check whether query execute

			if($res==TRUE)
			{
				// executed and updated
				$_SESSION['update'] = "<div class='success'> Admin Update </div>"; 

				header("location:".SITEURL.'admin/manage-admin.php');
			}
			else
			{
				// failed to update
				$_SESSION['update'] = "<div class='error'> Admin Update failed </div> "; 

				header('location:'.SITEURL.'admin/manage-admin.php');
			}
		}
?>


<?php include('partials/footer.php'); ?>